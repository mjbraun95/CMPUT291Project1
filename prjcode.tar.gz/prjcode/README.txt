Mini-Project 1
mjbraun - 1497171
hettiara - 1580077
junhong1 - 1507735

We did not collaborate with anyone else for this project.

Running Instructions:
    1. From the command line, enter the command:
        python Login.py
    2. You will be prompted for a username and password. Once you have successfully signed in, you will be provided instructions to perform the tasks.